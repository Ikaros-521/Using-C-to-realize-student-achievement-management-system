#ifndef SAMS_H
#define SAMS_H
#define MAX_STU 100
#define MAX_TEA 50
// 系统初始化
void sams_init(void);
// 系统开始运行
void sams_start(void);
// 系统结束
void sams_exit(void);

#endif//SAMS_H
