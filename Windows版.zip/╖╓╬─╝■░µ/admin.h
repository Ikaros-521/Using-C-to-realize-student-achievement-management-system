#ifndef ADMIN_H
#define ADMIN_H

void admin_start(void);

#endif//ADMIN_H
