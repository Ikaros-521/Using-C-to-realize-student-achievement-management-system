#ifndef TEACHER_H
#define TEACHER_H

void teacher_ch_pw(void);

int teacher_login(void);

void teacher_start(void);

#endif//TEACHER_H
