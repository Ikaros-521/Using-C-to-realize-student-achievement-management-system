#include "sams.h"

int main()
{
	sams_init();
	
	sams_start();

	sams_exit();
}
