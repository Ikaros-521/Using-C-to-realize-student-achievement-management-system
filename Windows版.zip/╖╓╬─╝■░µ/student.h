#ifndef STUDENT_H
#define STUDENT_H

void student_start(void);

#endif//STUDENT_H
